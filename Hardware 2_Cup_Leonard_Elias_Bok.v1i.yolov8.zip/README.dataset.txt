# Hardware 2_Cup_Leonard_Elias_Bök > 2026-02-01 10:34pm
https://universe.roboflow.com/leonard-elias-bker/hardware-2_cup_leonard_elias_bok

Provided by a Roboflow user
License: CC BY 4.0

